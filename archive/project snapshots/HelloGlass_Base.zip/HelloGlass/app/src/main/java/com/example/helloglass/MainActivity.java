package com.example.helloglass;

import com.google.android.glass.widget.CardBuilder;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);

        View mView = new CardBuilder(this, CardBuilder.Layout.TEXT)
                .setText("A stack indicator can be added to the corner of a card...")
                .setFootnote("This is the footnote")
                .setTimestamp("just now")
                .setAttributionIcon(R.drawable.ic_play)
                .showStackIndicator(true)
                .getView();

        setContentView(mView);
    }


}

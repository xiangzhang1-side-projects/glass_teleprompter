package com.example.helloglass;

import com.google.android.glass.touchpad.Gesture;
import com.google.android.glass.widget.CardBuilder;
import com.google.android.glass.widget.CardScrollView;
import com.google.android.glass.widget.CardScrollAdapter;

import android.Manifest;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.TextView;
import android.view.WindowManager;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.ArrayList;

import edu.cmu.pocketsphinx.Assets;
import edu.cmu.pocketsphinx.Hypothesis;
import edu.cmu.pocketsphinx.RecognitionListener;
import edu.cmu.pocketsphinx.SpeechRecognizer;
import edu.cmu.pocketsphinx.SpeechRecognizerSetup;

public class MainActivity extends Activity implements RecognitionListener {

    private int iSlide;
    private String[] hotwords;
    private String[] texts;
    private long tStart;

    private List<CardBuilder> mCards;
    private CardScrollView mCardScrollView;
    private CardScrollAdapter mAdapter;

    private class ExampleCardScrollAdapter extends CardScrollAdapter {
        @Override
        public int getPosition(Object item) {
            return mCards.indexOf(item);
        }
        @Override
        public int getCount() {
            return mCards.size();
        }
        @Override
        public Object getItem(int position) {
            return mCards.get(position);
        }
        @Override
        public int getViewTypeCount() {
            return CardBuilder.getViewTypeCount();
        }
        @Override
        public int getItemViewType(int position){
            return mCards.get(position).getItemViewType();
        }
        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            return mCards.get(position).getView(convertView, parent);
        }
    }

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);   // keep screen on

        int nSlides = getResources().getInteger(R.integer.nslides);
        texts = getResources().getStringArray(R.array.texts);
        hotwords = getResources().getStringArray(R.array.hotwords);
        tStart = System.currentTimeMillis();

        mCards = new ArrayList<CardBuilder>();
        for (iSlide = 0; iSlide < nSlides; iSlide++) {
            String text = texts[iSlide];
            String footnote = hotwords[iSlide];
            String timestamp = "TBD";
            mCards.add(new CardBuilder(this, CardBuilder.Layout.TEXT)
                    .setText(text)
                    .setFootnote(footnote)
                    .setTimestamp(timestamp));
        }

        mAdapter = new ExampleCardScrollAdapter();

        mCardScrollView = new CardScrollView(this);
        mCardScrollView.setAdapter(mAdapter);
        mCardScrollView.activate();
        setContentView(mCardScrollView);

        mCardScrollView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                advanceSlide();
            }
        });

/* ---------- above: CardScrollerView -------------------- */
/* ---------- below: voice recognition -------------------- */

        iSlide = 0;
        setupRecognizer();
        listenFor(hotwords[iSlide]);
    }

    private SpeechRecognizer recognizer;

    // result handling

    @Override
    public void onPartialResult(Hypothesis hypothesis) {
        if (hypothesis == null)
            return;

        String text = hypothesis.getHypstr();
        if (text.equals(hotwords[iSlide])) {
            toast("heard that!");
            advanceSlide();
        }
    }

    @Override
    public void onResult(Hypothesis hypothesis) {
    }


    // toolset

    private void listenFor(String text) {
        if (recognizer != null) {
            recognizer.stop();
        }

        recognizer.addKeyphraseSearch(text, text);
        recognizer.startListening(text);

        toast("ready!");
    }

    private void toast(String text) {
        System.out.println(text);
    }

    private void setupRecognizer() {

        try {
            Assets assets = new Assets(MainActivity.this);
            File assetsDir = assets.syncAssets();

            recognizer = SpeechRecognizerSetup.defaultSetup()
                    .setAcousticModel(new File(assetsDir, "en-us-ptm"))
                    .setDictionary(new File(assetsDir, "cmudict-en-us.dict"))
                    //.setRawLogDir(assetsDir)                      // don't save raw audio files
                    .getRecognizer();
            recognizer.addListener(this);

        } catch (IOException e){
            System.out.println(e.getMessage());
        }
    }

    // boilerplate

    @Override
    public void onBeginningOfSpeech() {
    }

    @Override
    public void onEndOfSpeech() {
    }

    @Override
    public void onError(Exception error) {
        System.out.println(error.getMessage());
    }

    @Override
    public void onTimeout() {
    }

    @Override
    public void onStop() {
        super.onStop();
        if (recognizer != null) {
            recognizer.cancel();
            recognizer.shutdown();
        }
    }

    // advanceSlide, http request

    public void advanceSlide() {
        iSlide += 1;
        // next slide; new timestamp
        long tEnd = System.currentTimeMillis();
        long tDelta = tEnd - tStart;
        long elapsedSeconds = tDelta / 1000;
        long minute = elapsedSeconds / 60;
        long second = elapsedSeconds % 60;
        mCards.get(iSlide).setText(String.format("%s:%s", minute, second));
        //must have this next line to see change reflected in glass
        mAdapter.notifyDataSetChanged();
        // mCardScrollView.animate(iSlide, CardScrollView.Animation.INSERTION);
        mCardScrollView.setSelection(iSlide);
        Gesture.SWIPE_RIGHT
        // new voice recog
        listenFor(hotwords[iSlide]);
    }

    public void nextKeynoteSlide() {
        // Instantiate the RequestQueue.
        RequestQueue queue = Volley.newRequestQueue(this);
        String url ="http://www.google.com";

        // Request a string response from the provided URL.
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // Display the first 500 characters of the response string.
                        mTextView.setText("Response is: "+ response.substring(0,500));
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {}
            });

        // Add the request to the RequestQueue.
        queue.add(stringRequest);
    }

}

package com.example.helloglass;

import com.google.android.glass.widget.CardBuilder;
import com.google.android.glass.widget.CardScrollView;
import com.google.android.glass.widget.CardScrollAdapter;

import android.Manifest;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.view.WindowManager;

import java.io.File;
import java.io.IOException;

import edu.cmu.pocketsphinx.Assets;
import edu.cmu.pocketsphinx.Hypothesis;
import edu.cmu.pocketsphinx.RecognitionListener;
import edu.cmu.pocketsphinx.SpeechRecognizer;
import edu.cmu.pocketsphinx.SpeechRecognizerSetup;

public class MainActivity extends Activity implements RecognitionListener {

    private SpeechRecognizer recognizer;
    private String LISTENFOR = "oh might computer";

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);   // keep screen on

        setupRecognizer();
        listenFor(LISTENFOR);

        View mView = new CardBuilder(this, CardBuilder.Layout.TEXT)
                .setText("A stack indicator can be added to the corner of a card...")
                .setFootnote("This is the footnote")
                .setTimestamp("just now")
                .setAttributionIcon(R.drawable.ic_play)
                .showStackIndicator(true)
                .getView();

        setContentView(mView);
    }

    // result handling

    @Override
    public void onPartialResult(Hypothesis hypothesis) {
        if (hypothesis == null)
            return;

        String text = hypothesis.getHypstr();
        if (text.equals(LISTENFOR)) {
            toast("heard that!");
            listenFor(LISTENFOR);
        }
    }

    @Override
    public void onResult(Hypothesis hypothesis) {
    }

    // tools

    private void setupRecognizer() {

        try {
            Assets assets = new Assets(MainActivity.this);
            File assetsDir = assets.syncAssets();

            recognizer = SpeechRecognizerSetup.defaultSetup()
                    .setAcousticModel(new File(assetsDir, "en-us-ptm"))
                    .setDictionary(new File(assetsDir, "cmudict-en-us.dict"))
                    //.setRawLogDir(assetsDir)                      // don't save raw audio files
                    .getRecognizer();
            recognizer.addListener(this);

        } catch (IOException e){
            System.out.println(e.getMessage());
        }
    }

    private void listenFor(String text) {
        if (recognizer != null) {
            recognizer.stop();
        }

        recognizer.addKeyphraseSearch(text, text);
        recognizer.startListening(text);

        toast("ready!");
    }

    private void toast(String text) {
        System.out.println(text);
    }

    // boilerplate

    @Override
    public void onBeginningOfSpeech() {
    }

    @Override
    public void onEndOfSpeech() {
    }

    @Override
    public void onError(Exception error) {
        System.out.println(error.getMessage());
    }

    @Override
    public void onTimeout() {
    }

    @Override
    public void onStop() {
        super.onStop();
        if (recognizer != null) {
            recognizer.cancel();
            recognizer.shutdown();
        }
    }

}

package com.example.bluetoothtest;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends AppCompatActivity {
    private BluetoothAdapter bluetoothAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // enable bluetooth
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_COARSE_LOCATION}, 1);
        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        // client: search
        IntentFilter filter = new IntentFilter(BluetoothDevice.ACTION_FOUND);
        registerReceiver(receiver, filter);
        bluetoothAdapter.startDiscovery();

    }

    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (BluetoothDevice.ACTION_FOUND.equals(action)) {
                // Discovery has found a device. Get the BluetoothDevice object and its info from the Intent.
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                String deviceName = device.getName();
                String deviceHardwareAddress = device.getAddress(); // MAC address

                toast(deviceName);
                toast(deviceHardwareAddress);

                // THE device
                if (deviceHardwareAddress != null && deviceHardwareAddress.equals("18:65:90:CF:A2:1C")) {
                    connect(device);
                }
            }
        }
    };

    private void connect(BluetoothDevice device) {
        toast("connecting to Device " + device.getName());
        bluetoothAdapter.cancelDiscovery();

        try {
            // client: connect to socket
            BluetoothSocket socket = device.createInsecureRfcommSocketToServiceRecord(UUID.fromString("e11c6340-2ffd-11e9-b210-d663bd873d93"));
            toast("socket created");
            socket.connect();
            toast("socket connected");
            OutputStream mmOutStream = socket.getOutputStream();
            toast("outstream obtained");
            // message over bluetooth
            mmOutStream.write("1".getBytes());
            mmOutStream.write("2".getBytes());
            mmOutStream.write("Next".getBytes());
            toast("written");
        } catch (Exception IOException) {
            toast("IOException");
        }
    }

    private void toast(String text) {
        // Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
        System.out.println("=============================" + text);
    }
}
